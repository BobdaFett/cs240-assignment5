#include "ATM.h"

using namespace ATM;

ATMClass::ATMClass() {
	state = State::START;
	currentCustomer = nullptr;
	currentAccount = nullptr;
	session = nullptr;
}

void ATMClass::Reset() {
	this->state = State::START;
}

void ATMClass::SetCustomerNumber(int number) {
	this->customerNumber = number;
	this->state = State::PIN;
}

Boolean ATMClass::SelectCustomer(int pin) {
	// Create a connection to the server.
	session = gcnew Session();

	// Initialize resources.
	currentCustomer = gcnew Customer(customerNumber, pin, session);
	if (currentCustomer->GetNumber() != Int32::MinValue) {
		this->state = State::ACCOUNT;
		return true;
	}
	else {
		this->state = State::START;
		return false;
	}
}

void ATMClass::SelectAccount(AccType accountType) {
	switch (accountType) {
	case AccType::CHECKING:
		currentAccount = currentCustomer->GetCheckingAccount();  // TODO Returns a nullptr
		Console::WriteLine("Changed to checking account, account number {0}", currentAccount->GetNumber());
		break;
	case AccType::SAVINGS:
		currentAccount = currentCustomer->GetSavingsAccount();
		Console::WriteLine("Changed to savings account, account number {0}", currentAccount->GetNumber());
		break;
	}
	this->state = State::TRANSACT;
}

void ATMClass::Withdraw(double value) {
	// Run store data? Maybe when changing the state.
	this->currentAccount->Withdraw(value);
}

void ATMClass::Deposit(double value) {
	// Run store data? Maybe when changing the state.
	this->currentAccount->Deposit(value);
}

double ATMClass::GetBalance() {
	return this->currentAccount->GetBalance();
}

void ATMClass::Back() {
	// switch handles everything EXECPT State::START, because Application::Exit is better placed in the form itself.
	switch (state) {
	case State::ACCOUNT:
		CloseAll();
		state = State::START;
		break;
	case State::PIN:
		state = State::START;
		break;
	case State::TRANSACT:
		// Save data to the BankData before leaving the page.
		currentAccount->StoreBalance();
		state = State::ACCOUNT;
		break;
	}
}

State ATMClass::GetState() {
	return this->state;
}

void ATMClass::CloseAll() {
	// disconnect?
	delete session;
}